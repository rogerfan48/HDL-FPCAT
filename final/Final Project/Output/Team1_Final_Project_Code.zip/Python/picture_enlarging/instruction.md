# Instructions

- 創建一個新的虛擬環境: `python3 -m venv myenv`
- 啟動虛擬環境: `.\myenv\bin\activate.ps1`
- 安裝所需模組: `pip install Pillow`
- 執行: `python3 enlarger.py`
- 退出虛擬環境: `deactivate`